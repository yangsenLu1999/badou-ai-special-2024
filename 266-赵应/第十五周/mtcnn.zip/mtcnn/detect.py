import cv2

import mtcnn.mtcnn_net as mtcnn

if __name__ == '__main__':
    img = cv2.imread("img/test1.jpg")
    threshold = [.5, .6, .7]
    mtcnn_net = mtcnn.MtCnn()
    rectangles = mtcnn_net.detect_face(img, threshold)
    print(rectangles)
    draw = img.copy()
    for rectangle in rectangles:
        if rectangle is not None:
            w = int(rectangle[2]) - int(rectangle[0])
            h = int(rectangle[3]) - int(rectangle[1])
            paddingH = .01 * w
            paddingW = .02 * h
            crop_img = img[int(rectangle[1] + paddingH): int(rectangle[3] - paddingH),
                       int(rectangle[0] - paddingW): int(rectangle[2] + paddingW)]
            if crop_img is None:
                continue
            if crop_img.shape[0] < 0 or crop_img.shape[1] < 0:
                continue
            cv2.rectangle(draw, (int(rectangle[0]), int(rectangle[1])), (int(rectangle[2]), int(rectangle[3])),
                          (255, 0, 0), 1)
            for i in range(5, 15, 2):
                cv2.circle(draw, (int(rectangle[i + 0]), int(rectangle[i + 1])), 2, (0, 255, 0))
    cv2.imwrite("img/out.jpg", draw)
    cv2.imshow("out", draw)
    cv2.waitKey(0)
