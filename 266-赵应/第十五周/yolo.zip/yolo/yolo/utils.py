import numpy as np
import tensorflow as tf
from PIL import Image


def letterbox_image(img, size):
    """
    等比例缩放图像
    :param img: 原图
    :param size: 目标尺寸(w,h)
    :return: 缩放后的图像
    """
    img_h, img_w = img.size
    w, h = size
    # 1.0用于增加精度
    new_w = int(img_w * min(w * 1.0 / img_w, h * 1.0 / img_h))
    new_h = int(img_h * min(w * 1.0 / img_w, h * 1.0 / img_h))
    # resize是PIL的，参数为(width, height)
    resized_img = img.resize((new_w, new_h), Image.BICUBIC)

    boxed_img = Image.new('RGB', size, (128, 128, 128))
    boxed_img.paste(resized_img, ((w - new_w) // 2, (h - new_h) // 2))
    return boxed_img


def load_weights(var_list, weights_file):
    with open(weights_file, 'rb') as fp:
        _ = np.fromfile(fp, dtype=np.int32, count=5)
        weights = np.fromfile(fp, dtype=np.float32)

    ptr = 0
    i = 0
    assign_ops = []
    while i < len(var_list) - 1:
        var1 = var_list[i]
        var2 = var_list[i + 1]
        # do something only if we process conv layer
        if 'conv2d' in var1.name.split('/')[-2]:
            if 'batch_normalization' in var2.name.split('/')[-2]:
                # load batch norm params
                gamma, beta, mean, var = var_list[i + 1:i + 5]
                batch_norm_vars = [beta, gamma, mean, var]
                for _var in batch_norm_vars:
                    shape = _var.shape.as_list()
                    # shape内元素的乘积
                    num_params = np.prod(shape)
                    var_weights = weights[ptr: ptr + num_params].reshape(shape)
                    ptr += num_params
                    assign_ops.append(tf.assign(_var, var_weights, validate_shape=True))

                # we move the pointer by 4, because we loaded 4 variables
                i += 4
            elif 'conv2d' in var2.name.split('/')[-2]:
                # load biases
                bias = var2
                bias_shape = bias.shape.as_list()
                bias_params = np.prod(bias_shape)
                bias_weights = weights[ptr: ptr + bias_params].reshape(bias_shape)
                ptr += bias_params
                assign_ops.append(tf.assign(bias, bias_weights, validate_shape=True))

                # we loaded 1 variable
                i += 1
            # we can load weights of conv layer
            shape = var1.shape.as_list()
            num_params = np.prod(shape)
            var_weights = weights[ptr: ptr + num_params].reshape((shape[3], shape[2], shape[0], shape[1]))
            # remember to transpose to column-major
            var_weights = np.transpose(var_weights, (2, 3, 1, 0))
            ptr += num_params
            assign_ops.append(tf.assign(var1, var_weights, validate_shape=True))
            i += 1
    return assign_ops
