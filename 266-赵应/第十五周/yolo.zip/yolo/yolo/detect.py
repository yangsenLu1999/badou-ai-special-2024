import os

import numpy as np
import tensorflow as tf
from PIL import Image,ImageDraw,ImageFont
from tensorflow.python import debug as tf_debug

import yolo.config as config
import yolo.utils as utils
from yolo.model import yolo_v3

# 指定使用GPU的Index
os.environ["CUDA_VISIBLE_DEVICES"] = config.gpu_index


def detect(image_path, model_path, yolo_weights=None):
    """
    1、加载需要检测的图片
    2、加载模型进行检测
    """
    img = Image.open(image_path)
    resize_img = utils.letterbox_image(img, (416, 416))
    img_data = np.array(resize_img, dtype=np.float32)
    # 归一化处理
    img_data /= 255.0

    # (416,416,3) -> (1,416,416,3)
    img_data = np.expand_dims(img_data, axis=0)

    input_img_shape = tf.placeholder(dtype=tf.float32, shape=(2,))
    input_image = tf.placeholder(dtype=tf.float32, shape=[None, 416, 416, 3])

    # 加载yolo检测网络
    predictor = yolo_v3.YoloV3(config.norm_epsilon, config.norm_decay, config.anchors_path, config.classes_path, False)
    with tf.Session() as sess:
        # sess = tf_debug.LocalCLIDebugWrapperSession(sess)
        if yolo_weights is not None:
            with tf.variable_scope('predict'):
                boxes, scores, classes = predictor.predict(input_image, input_img_shape, config)
            # 这里使用的是权重文件，使用方式和h5模型文件不太一致
            load_op = utils.load_weights(tf.global_variables('predict'), yolo_weights)
            sess.run(load_op)
            feed_dict = {
                input_image: img_data,
                # 以h,w的形式传入
                input_img_shape: [img.size[1], img.size[0]]
            }
            out_boxes, out_scores, out_classes = sess.run([boxes, scores, classes], feed_dict=feed_dict)
        else:
            boxes, scores, classes = predictor.predict(input_image, input_img_shape)
            saver = tf.train.Saver()
            saver.restore(sess, model_path)
            feed_dict = {
                input_image: img_data,
                # 以h,w的形式传入
                input_img_shape: [img.size(1), img.size(0)]
            }
            out_boxes, out_scores, out_classes = sess.run([boxes, scores, classes], feed_dict=feed_dict)
        print('Found {} boxes for {}'.format(len(out_boxes), 'img'))
        font = ImageFont.truetype(font='font/FiraMono-Medium.otf',
                                  size=np.floor(3e-2 * img.size[1] + 0.5).astype('int32'))
        # 将预测的结果显示到原图上
        thickness = (img.size[0] + img.size[1]) // 300
        for i, c in reversed(list(enumerate(out_classes))):
            # 获得预测名字，box和分数
            predicted_class = predictor.classes[c]
            box = out_boxes[i]
            score = out_scores[i]
            label = '{} {:.2f}'.format(predicted_class, score)
            # 用于画框框和文字
            draw = ImageDraw.Draw(img)
            # textsize用于获得写字的时候，按照这个字体，要多大的框
            label_size = draw.textsize(label, font)

            # 获得四个边
            top, left, bottom, right = box
            top = max(0, np.floor(top + 0.5).astype('int32'))
            left = max(0, np.floor(left + 0.5).astype('int32'))
            bottom = min(img.size[1] - 1, np.floor(bottom + 0.5).astype('int32'))
            right = min(img.size[0] - 1, np.floor(right + 0.5).astype('int32'))
            print(label, (left, top), (right, bottom))
            print(label_size)

            if top - label_size[1] >= 0:
                text_origin = np.array([left, top - label_size[1]])
            else:
                text_origin = np.array([left, top + 1])

            # My kingdom for a good redistributable image drawing library.
            for i in range(thickness):
                draw.rectangle(
                    [left + i, top + i, right - i, bottom - i],
                    outline=predictor.colors[c])
            draw.rectangle(
                [tuple(text_origin), tuple(text_origin + label_size)],
                fill=predictor.colors[c])
            draw.text(text_origin, label, fill=(0, 0, 0), font=font)
            del draw
        img.show()
        img.save('./img/result1.jpg')


if __name__ == '__main__':
    detect(config.image_file, config.model_dir, config.yolo3_weights_path)
