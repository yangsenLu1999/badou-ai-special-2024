import os
import sys
import numpy as np
import tensorflow as tf


def conv2d_layer(inputs, filters_num, kernel_size, strides, name, use_bias=False):
    """
    Introduction
    ------------
        使用tf.layers.conv2d减少权重和偏置矩阵初始化过程，以及卷积后加上偏置项的操作
        经过卷积之后需要进行batch norm，最后使用leaky ReLU激活函数
        根据卷积时的步长，如果卷积的步长为2，则对图像进行降采样
        比如，输入图片的大小为416*416，卷积核大小为3，若stride为2时，（416 - 3 + 2）/ 2 + 1， 计算结果为208，相当于做了池化层处理
        因此需要对stride大于1的时候，先进行一个padding操作, 采用四周都padding一维代替'same'方式
    Parameters
    ----------
        inputs: 输入变量
        filters_num: 卷积核数量
        kernel_size: 卷积核大小
        strides: 卷积步长
        name: 卷积层名字
        trainging: 是否为训练过程
        use_bias: 是否使用偏置项
    Returns
    -------
        conv: 卷积之后的feature map
    """
    conv = tf.layers.conv2d(inputs=inputs, filters=filters_num, kernel_size=kernel_size, strides=strides,
                            padding=('SAME' if strides == 1 else 'VALID'),
                            name=name, use_bias=use_bias,
                            kernel_initializer=tf.glorot_uniform_initializer(),
                            kernel_regularizer=tf.contrib.layers.l2_regularizer(scale=5e-4))
    return conv


def batch_normalization_layer(inputs, name=None, training=True, norm_decay=.99, norm_epsilon=1e-3):
    """
    对上一层提取的特征做BN处理
    :param inputs: 输入的四维tensor
    :param name: batchnorm层的名字
    :param training: 是否为训练过程
    :param norm_decay: 在预测时计算moving average时的衰减率
    :param norm_epsilon: 方差加上极小的数，防止除以0的情况
    :return: batch normalization处理之后的feature map
    """
    bn = tf.layers.batch_normalization(inputs=inputs, momentum=norm_decay, epsilon=norm_epsilon, center=True,
                                       scale=True,
                                       training=training, name=name)
    return tf.nn.leaky_relu(bn, alpha=.1)


def residual_block(inputs, filters_num, blocks_num, conv_index, norm_decay=.99, norm_epsilon=1e-3, training=True):
    """
    Darknet的残差block，类似resnet的两层卷积结构，分别采用1x1和3x3的卷积核，使用1x1是为了减少channel的维度
    :param inputs:
    :param filters_num: 卷积核个数
    :param blocks_num: block的数量
    :param conv_index:
    :param norm_decay: 在预测时计算moving average时的衰减率
    :param norm_epsilon: 方差加上极小的数，防止除以0的情况
    :param training:
    :return:
    """
    # 在输入feature map的长宽维度进行padding
    inputs = tf.pad(inputs, paddings=[[0, 0], [1, 0], [1, 0], [0, 0]], mode='CONSTANT')
    layer = conv2d_layer(inputs, filters_num, kernel_size=3, strides=2, name='conv2d_' + str(conv_index))
    layer = batch_normalization_layer(layer, name='batch_normalization_' + str(conv_index), training=training,
                                      norm_decay=norm_decay, norm_epsilon=norm_epsilon)
    conv_index += 1
    for _ in range(blocks_num):
        shortcut = layer
        layer = conv2d_layer(layer, filters_num // 2, kernel_size=1, strides=1, name='conv2d_' + str(conv_index))
        layer = batch_normalization_layer(layer, name='batch_normalization_' + str(conv_index), training=training,
                                          norm_decay=norm_decay, norm_epsilon=norm_epsilon)
        conv_index += 1
        layer = conv2d_layer(layer, filters_num, kernel_size=3, strides=1, name='conv2d_' + str(conv_index))
        layer = batch_normalization_layer(layer, name='batch_normalization_' + str(conv_index), training=training,
                                          norm_decay=norm_decay, norm_epsilon=norm_epsilon)
        conv_index += 1
        layer += shortcut
        return layer, conv_index


def darknet53(inputs, conv_index, training=True, norm_decay=.99, norm_epsilon=1e-3):
    """
    Introduction
    ------------
        构建yolo3使用的darknet53网络结构
    Parameters
    ----------
        inputs: 模型输入变量
        conv_index: 卷积层数序号，方便根据名字加载预训练权重
        training: 是否为训练
        norm_decay: 在预测时计算moving average时的衰减率
        norm_epsilon: 方差加上极小的数，防止除以0的情况
    Returns
    -------
        conv: 经过52层卷积计算之后的结果, 输入图片为416x416x3，则此时输出的结果shape为13x13x1024
        route1: 返回第26层卷积计算结果52x52x256, 供后续使用
        route2: 返回第43层卷积计算结果26x26x512, 供后续使用
        conv_index: 卷积层计数，方便在加载预训练模型时使用
    """
    with tf.variable_scope('darknet53'):
        # 416,416,3 -> 416,416,32
        conv = conv2d_layer(inputs, 32, 3, strides=1, name='conv2d_' + str(conv_index))
        conv = batch_normalization_layer(conv, name='batch_normalization_' + str(conv_index),
                                         training=training, norm_decay=norm_decay, norm_epsilon=norm_epsilon)
        conv_index += 1

        # 416,416,32 -> 208,208,64
        conv, conv_index = residual_block(conv, 64, blocks_num=1, training=training, norm_decay=norm_decay,
                                          norm_epsilon=norm_epsilon, conv_index=conv_index)
        # 208,208,64 -> 104,104,128
        conv, conv_index = residual_block(conv, conv_index=conv_index, filters_num=128, blocks_num=2,
                                          training=training, norm_decay=norm_decay, norm_epsilon=norm_epsilon)
        # 104,104,128 -> 52,52,256
        conv, conv_index = residual_block(conv, conv_index=conv_index, filters_num=256, blocks_num=8,
                                          training=training, norm_decay=norm_decay, norm_epsilon=norm_epsilon)
        # route1 = 52,52,256
        route1 = conv
        # 52,52,256 -> 26,26,512
        conv, conv_index = residual_block(conv, conv_index=conv_index, filters_num=512, blocks_num=8,
                                          training=training, norm_decay=norm_decay, norm_epsilon=norm_epsilon)
        # route2 = 26,26,512
        route2 = conv
        # 26,26,512 -> 13,13,1024
        conv, conv_index = residual_block(conv, conv_index=conv_index, filters_num=1024, blocks_num=4,
                                          training=training, norm_decay=norm_decay, norm_epsilon=norm_epsilon)
        # route3 = 13,13,1024
        return route1, route2, conv, conv_index


def yolo_block(inputs, filters_num, out_filters, conv_index, training=True, norm_decay=.99, norm_epsilon=1e-3):
    """
    yolo3在Darknet53提取的特征层基础上，又加了针对3种不同比例的feature map的block，这样来提高对小物体的检测率
    输出两个网络结果：
        第一个是进行5次卷积后，用于下一次逆卷积的，卷积过程是1X1，3X3，1X1，3X3，1X1
        第二个是进行5+2次卷积，作为一个特征层的，卷积过程是1X1，3X3，1X1，3X3，1X1，3X3，1X1
    :param inputs:
    :param filters_num: 卷积核数量
    :param out_filters: 最后输出层的卷积核数量
    :param conv_index: 卷积层数序号，方便根据名字加载预训练权重
    :param training: 是否为训练
    :param norm_decay: 在预测时计算moving average时的衰减率
    :param norm_epsilon: 方差加上极小的数，防止除以0的情况
    :return:route: 返回最后一层卷积的前一层结果
            conv: 返回最后一层卷积的结果
            conv_index: conv层计数
    """
    conv = conv2d_layer(inputs, filters_num, kernel_size=1, strides=1, name='conv2d_' + str(conv_index))
    conv = batch_normalization_layer(conv, name="batch_normalization_" + str(conv_index), training=training,
                                     norm_decay=norm_decay, norm_epsilon=norm_epsilon)
    conv_index += 1
    conv = conv2d_layer(conv, filters_num * 2, kernel_size=3, strides=1, name='conv2d_' + str(conv_index))
    conv = batch_normalization_layer(conv, name="batch_normalization_" + str(conv_index), training=training,
                                     norm_decay=norm_decay, norm_epsilon=norm_epsilon)
    conv_index += 1
    conv = conv2d_layer(conv, filters_num, kernel_size=1, strides=1, name='conv2d_' + str(conv_index))
    conv = batch_normalization_layer(conv, name="batch_normalization_" + str(conv_index), training=training,
                                     norm_decay=norm_decay, norm_epsilon=norm_epsilon)
    conv_index += 1
    conv = conv2d_layer(conv, filters_num * 2, kernel_size=3, strides=1, name='conv2d_' + str(conv_index))
    conv = batch_normalization_layer(conv, name="batch_normalization_" + str(conv_index), training=training,
                                     norm_decay=norm_decay, norm_epsilon=norm_epsilon)
    conv_index += 1
    conv = conv2d_layer(conv, filters_num, kernel_size=1, strides=1, name='conv2d_' + str(conv_index))
    conv = batch_normalization_layer(conv, name="batch_normalization_" + str(conv_index), training=training,
                                     norm_decay=norm_decay, norm_epsilon=norm_epsilon)
    conv_index += 1
    route = conv
    conv = conv2d_layer(conv, filters_num * 2, kernel_size=3, strides=1, name='conv2d_' + str(conv_index))
    conv = batch_normalization_layer(conv, name="batch_normalization_" + str(conv_index), training=training,
                                     norm_decay=norm_decay, norm_epsilon=norm_epsilon)
    conv_index += 1
    conv = conv2d_layer(conv, out_filters, kernel_size=1, strides=1, name='conv2d_' + str(conv_index), use_bias=True)
    conv_index += 1
    return route, conv, conv_index


def boxes_and_scores(yolo_output, anchors, classes_num, input_shape, image_shape):
    """
    :param yolo_output:
    :param anchors:
    :param classes_num:
    :param input_shape:
    :param image_shape:
    :return: boxes: 物体框的位置
            boxes_scores: 物体框的分数，为置信度和类别概率的乘积
    """
    # 获得特征
    box_xy, box_wh, box_confidence, box_class_probs = get_features(yolo_output, anchors, classes_num, input_shape)
    # 寻找在原图上的位置
    boxes = correct_boxes(box_xy, box_wh, input_shape, image_shape)
    # *x4
    boxes = tf.reshape(boxes, [-1, 4])
    # 获得置信度box_confidence * box_class_probs
    boxes_scores = box_class_probs * box_confidence
    # *x4
    boxes_scores = tf.reshape(boxes_scores, [-1, classes_num])
    return boxes, boxes_scores


def get_features(yolo_output, anchors, class_num, input_shape):
    """
    :param yolo_output:
    :param anchors:
    :param class_num:
    :param input_shape:
    :return: box_xy, box_wh, box_confidence, box_class_probs
    """
    num_anchors = len(anchors)
    anchor_tensor = tf.reshape(tf.constant(anchors, dtype=tf.float32), [1, 1, 1, num_anchors, 2])
    grid_size = tf.shape(yolo_output)[1:3]
    predictions = tf.reshape(yolo_output, [-1, grid_size[0], grid_size[1], num_anchors, class_num + 5])
    # 这里构建13*13*1*2的矩阵，对应每个格子加上对应的坐标
    grid_y = tf.tile(tf.reshape(tf.range(grid_size[0]), [-1, 1, 1, 1]), [1, grid_size[1], 1, 1])
    grid_x = tf.tile(tf.reshape(tf.range(grid_size[1]), [-1, 1, 1, 1]), [1, grid_size[0], 1, 1])
    grid = tf.concat([grid_x, grid_y], axis=-1)
    grid = tf.cast(grid, tf.float32)

    # 将x,y坐标归一化，相对网格的位置
    box_xy = (tf.sigmoid(predictions[..., :2]) + grid) / tf.cast(grid_size[::-1], tf.float32)
    # 将w,h也归一化
    box_wh = tf.exp(predictions[..., 2:4]) * anchor_tensor / tf.cast(input_shape[::-1], tf.float32)

    box_confidence = tf.sigmoid(predictions[..., 4:5])
    box_class_probs = tf.sigmoid(predictions[..., 5:])

    return box_xy, box_wh, box_confidence, box_class_probs


def correct_boxes(box_xy, box_wh, input_shape, image_shape):
    """
    :param box_xy:
    :param box_wh:
    :param input_shape:
    :param image_shape:
    :return: boxes: 物体框的位置
    """
    box_yx = box_xy[..., ::-1]
    box_hw = box_wh[..., ::-1]
    input_shape = tf.cast(input_shape, tf.float32)
    image_shape = tf.cast(image_shape, tf.float32)
    new_shape = tf.round(tf.reduce_min(input_shape / image_shape) * image_shape)
    offset = (input_shape - new_shape) / 2.0 / input_shape
    scale = input_shape / new_shape
    box_yx = (box_yx - offset) * scale
    box_hw = box_hw * scale

    box_mines = box_yx - (box_hw / 2.0)
    box_maxes = box_yx + (box_hw / 2.0)
    boxes = tf.concat([
        box_mines[..., 0:1],
        box_mines[..., 1:2],
        box_maxes[..., 0:1],
        box_maxes[..., 1:2]
    ], axis=-1)
    boxes *= tf.concat([image_shape, image_shape], axis=-1)
    return boxes


class YoloV3:
    def __init__(self, norm_epsilon, norm_decay, anchors_path, classes_path, pre_train):
        """

        :param norm_epsilon: 在预测时计算moving average时的衰减率
        :param norm_decay: 方差加上极小的数，防止除以0的情况
        :param anchors_path: yolo anchor 文件路径
        :param classes_path: 数据集类别对应文件
        :param pre_train: 是否使用预训练darknet53模型
        """
        self.norm_epsilon = norm_epsilon
        self.norm_decay = norm_decay
        self.anchors_path = anchors_path
        self.classes_path = classes_path
        self.pre_train = pre_train
        self.anchors = self._get_anchors()
        self.classes = self._get_classes()

    def _get_anchors(self):
        anchors_path = os.path.expanduser(self.anchors_path)
        with open(anchors_path, encoding='utf-8') as f:
            anchors = f.readline()
        anchors = [float(x) for x in anchors.split(',')]
        return np.array(anchors).reshape(-1, 2)

    def _get_classes(self):
        classes_path = os.path.expanduser(self.classes_path)
        with open(classes_path, encoding='utf-8') as f:
            classes = f.readlines()
        classes = [line.strip() for line in classes]
        return classes

    def yolo_inference(self, inputs, config, training=True):
        num_anchors = config.num_anchors // 3
        num_classes = config.num_classes
        norm_decay = config.norm_decay
        norm_epsilon = config.norm_epsilon
        conv_index = 1

        # 抽取通用特征
        # conv2d_26 = 52,52,256、conv2d_43 = 26,26,512、conv = 13,13,1024
        conv2d_26, conv2d_43, conv, conv_index = darknet53(inputs, conv_index, training=training,
                                                           norm_decay=config.norm_decay,
                                                           norm_epsilon=config.norm_epsilon)
        with tf.variable_scope('yolo'):
            # --------------------------------------#
            #   获得第一个特征层
            # --------------------------------------#
            # conv2d_57 = 13,13,512，conv2d_59 = 13,13,255(3x(80+5))
            conv2d_57, conv2d_59, conv_index = yolo_block(conv, 512, num_anchors * (num_classes + 5),
                                                          conv_index=conv_index, training=training,
                                                          norm_decay=norm_decay, norm_epsilon=norm_epsilon)
            # --------------------------------------#
            #   获得第二个特征层
            # --------------------------------------#
            conv2d_60 = conv2d_layer(conv2d_57, filters_num=256, kernel_size=1, strides=1,
                                     name="conv2d_" + str(conv_index))
            conv2d_60 = batch_normalization_layer(conv2d_60, name="batch_normalization_" + str(conv_index),
                                                  training=training, norm_decay=norm_decay,
                                                  norm_epsilon=norm_epsilon)
            conv_index += 1
            # unSample_0 = 26,26,256
            unSample_0 = tf.image.resize_nearest_neighbor(conv2d_60,
                                                          [2 * tf.shape(conv2d_60)[1], 2 * tf.shape(conv2d_60)[1]],
                                                          name='upSample_0')
            # route0 = 26,26,768
            route0 = tf.concat([unSample_0, conv2d_43], axis=-1, name='route_0')

            # conv2d_65 = 52,52,256，conv2d_67 = 26,26,255(3x(80+5))
            conv2d_65, conv2d_67, conv_index = yolo_block(route0, filters_num=256,
                                                          out_filters=num_anchors * (num_classes + 5),
                                                          conv_index=conv_index,
                                                          training=training, norm_decay=norm_decay,
                                                          norm_epsilon=norm_epsilon)

            # --------------------------------------#
            #   获得第三个特征层
            # --------------------------------------#
            conv2d_68 = conv2d_layer(conv2d_65, filters_num=128, kernel_size=1, strides=1,
                                     name='conv2d_' + str(conv_index))
            conv2d_68 = batch_normalization_layer(conv2d_68, name="batch_normalization_" + str(conv_index),
                                                  training=training, norm_decay=self.norm_decay,
                                                  norm_epsilon=self.norm_epsilon)
            conv_index += 1

            # upSample_1 = 52,52,128
            upSample_1 = tf.image.resize_nearest_neighbor(conv2d_68,
                                                          [2 * tf.shape(conv2d_68)[1], 2 * tf.shape(conv2d_68)[1]],
                                                          name='upSample_1')
            # route0 = 52,52,384
            route1 = tf.concat([upSample_1, conv2d_26], axis=-1, name='route1')

            #
            _, conv2d_75, _ = yolo_block(route1, filters_num=128, out_filters=num_anchors * (num_classes + 5),
                                         conv_index=conv_index,
                                         training=training, norm_decay=norm_decay, norm_epsilon=norm_epsilon)
            return [conv2d_59, conv2d_67, conv2d_75]

    def eval(self, inputs, image_shape, config, max_boxes=20):
        """

        :param config:
        :param inputs:
        :param image_shape: 原图大小
        :param max_boxes: 最大boxes 数量
        :return:
        boxes, scores, classes: 物体框位置，物体类别概率，物体类别
        """
        anchor_mask = [[6, 7, 8], [3, 4, 5], [0, 1, 2]]
        boxes = []
        box_scores = []
        input_shape = tf.shape(inputs[0])[1:3] * 32
        # 对三个特征层的输出获取每个预测box坐标和box的分数，score = 置信度x类别概率
        # ---------------------------------------#
        #   对三个特征层解码
        #   获得分数和框的位置
        # ---------------------------------------#
        for i in range(len(inputs)):
            _boxes, _boxe_scores = boxes_and_scores(inputs[i], self.anchors[anchor_mask[i]], len(self.classes),
                                                    input_shape, image_shape)
            boxes.append(_boxes)
            box_scores.append(_boxe_scores)

        # 放在一行里面便于操作
        boxes = tf.concat(boxes, axis=0)
        box_scores = tf.concat(box_scores, axis=0)
        mask = box_scores >= config.obj_threshold
        max_box_tensor = tf.constant(max_boxes, tf.int32)
        boxes_ = []
        scores_ = []
        classes_ = []
        # ---------------------------------------#
        #   1、取出每一类得分大于self.obj_threshold
        #   的框和得分
        #   2、对得分进行非极大抑制
        # ---------------------------------------#
        # 对每一个类进行判断
        for classify in range(len(self.classes)):
            # 取出所有类为c的box
            class_boxes = tf.boolean_mask(boxes, mask[:, classify])
            # 取出所有类为c的分数
            class_box_scores = tf.boolean_mask(box_scores[:, classify], mask[:, classify])
            # 非极大抑制
            nms_index = tf.image.non_max_suppression(class_boxes, class_box_scores, max_box_tensor,
                                                     iou_threshold=config.nms_threshold)
            # 获取非极大抑制的结果
            return nms_index
            class_boxes = tf.gather(class_boxes, nms_index)
            class_box_scores = tf.gather(class_box_scores, nms_index)
            classes = tf.ones_like(class_box_scores, tf.int32) * classify

            boxes_.append(class_boxes)
            scores_.append(class_box_scores)
            classes_.append(classes)
        boxes_ = tf.concat(boxes_, axis=0)
        scores_ = tf.concat(scores_, axis=0)
        classes_ = tf.concat(classes_, axis=0)
        return boxes_, scores_, classes_

    def predict(self, inputs, image_shape, config):
        # 获取网络的推断结果
        output = self.yolo_inference(inputs, config)
        boxes, scores, classes = self.eval(output, image_shape, config, 20)
        return boxes, scores, classes
